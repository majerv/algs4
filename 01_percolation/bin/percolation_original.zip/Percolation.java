
/**
 * Represents a percolation system.
 */
public class Percolation {

	private final int dimension;
	private final int sidesCount;
	
	private final boolean[] grid;
	
	private final WeightedQuickUnionUF unionFind;
	
	/**
	 *  Creates an N-by-N grid, with all sites blocked
	 * 
	 *  @param n the dimension of the grid
	 */
	public Percolation(int n) {
		if (n <= 0) {
			throw new IllegalArgumentException("Dimension of the grid must be positive");
		}
		
		this.dimension = n;
		this.sidesCount = n * n + 2; // add two virtual nodes
		
		this.grid = new boolean[sidesCount];
		this.unionFind = new WeightedQuickUnionUF(sidesCount);
		
		// union first row with 1st virtual node
		for (int j = 0; j < dimension; j++) {
			unionFind.union(getVirtualStartPoint(), j+1);
		}
		
		// union last row with 2nd virtual node
		// XXX affects the isFull method
		for (int j = 0; j < dimension; j++) {
			unionFind.union(getVirtualEndPoint(), getSideId(dimension, j+1));
		}
	}

	/**
	 *  Opens site (row i, column j) if it is not open already
	 *  @param i
	 *  @param j
	 */
	public void open(int i, int j) {
		checkIndices(i, j);
		
		final int sideId = getSideId(i, j);
		
		// open the site
		grid[getSideId(i, j)] = true;
		
		// connect it with its neighbours
		// left
		if (j > 1 && isOpen(i, j-1)) {
			unionFind.union(sideId, getSideId(i, j-1));
		}

		// right
		if (j < dimension && isOpen(i, j+1)) {
			unionFind.union(sideId, getSideId(i, j+1));
		}

		// top
		if (i > 1 && isOpen(i-1, j)) {
			unionFind.union(sideId, getSideId(i-1, j));
		}

		// bottom
		if (i < dimension && isOpen(i+1, j)) {
			unionFind.union(sideId, getSideId(i+1, j));
		}
	}

	/**
	 * is site (row i, column j) open?
	 * @param i
	 * @param j
	 * @return
	 */
	public boolean isOpen(final int i, final int j) {
		checkIndices(i, j);
		return grid[getSideId(i, j)];
	}

	/**
	 *  is site (row i, column j) full?
	 * @param i
	 * @param j
	 * @return
	 */
	public boolean isFull(int i, int j) {
		checkIndices(i, j);
		
		// check if 1st virtual node is connected to the side & open
		return unionFind.connected(getVirtualStartPoint(), getSideId(i, j)) && isOpen(i, j);
	}

	/**
	 * does the system percolate?
	 * @return
	 */
	public boolean percolates() {
		// check if the two virtual nodes are connected
		// FIXME
		return unionFind.connected(getVirtualStartPoint(), getVirtualEndPoint());

//		for (int j = 0; j < dimension; j++) {
//			if (isOpen(dimension, j+1) && unionFind.connected(getVirtualStartPoint(), getSideId(dimension, j+1))) {
//				return true;
//			}
//		}
//		
//		return false;
	}

	private void checkIndices(int i, int j) {
		checkIndex(i);
		checkIndex(j);
	}

	private void checkIndex(int index) {
		// condition 1 <= index <= dimension must hold
		if (index < 1 || index > dimension) {
			throw new IndexOutOfBoundsException(String.format("Index must be between 1 and %s", dimension));
		}
	}
	
	private int getSideId(final int i, final int j) {
		return (i - 1) * dimension + j;
	}
	
	private int getVirtualStartPoint() {
		return 0;
	}
	
	private int getVirtualEndPoint() {
		return sidesCount - 1;
	}
	
}
